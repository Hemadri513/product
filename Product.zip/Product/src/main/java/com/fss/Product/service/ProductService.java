/**
 * 
 */
package com.fss.Product.service;

/**
 * @author Frame
 *
 */
public interface ProductService {

	String insert();

}
