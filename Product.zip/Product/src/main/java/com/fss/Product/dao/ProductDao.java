/**
 * 
 */
package com.fss.Product.dao;

/**
 * @author Frame
 *
 */
public interface ProductDao {

	boolean insert(String productId);

}
