package com.fss.Product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
@ComponentScan(basePackages = {"com.fss"})
public class ProductApplication {

	public static void main(String[] args) {
		System.out.println("Application Started Successfully");
		System.setProperty("spring.main.allow-bean-definition-overriding", "true");
		SpringApplication.run(ProductApplication.class, args);
	}

}
