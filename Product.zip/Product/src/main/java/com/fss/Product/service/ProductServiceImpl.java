package com.fss.Product.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fss.Product.dao.ProductDao;

@Service("productService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao dao;
	
	@Override
	public String insert() {
	String response="unable to insert";
		String productId="2";
		boolean value=dao.insert(productId);
		if(value) {
			response="inserted Succesfully";
		}
		
		return response;
	}

}
