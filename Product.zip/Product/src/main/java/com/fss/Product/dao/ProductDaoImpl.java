package com.fss.Product.dao;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

@Service("productDao")
public class ProductDaoImpl implements ProductDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductDaoImpl.class);
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
		
	@Override
	public boolean insert(String productId) {
		String firstname="test";
		String lastname="test2";
		String age="10";
		String query = "insert into people(first_name,last_name)values(:firstname,:lastname)";
		boolean	result = false;
		Map<String,String> inputparam = new HashMap<String,String>();
		inputparam.put("firstname", firstname);
		inputparam.put("lastname", lastname);
		int count=namedParameterJdbcTemplate.update(query, inputparam);
		if(count>0){
			result=true;
		}
		
		return result;
	}

}
